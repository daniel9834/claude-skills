---
name: session handoff
description: >
  Use this skill when the user types "session handoff", "do a session handoff", "run the session handoff skill",
  or says anything like "this chat is getting too long", "I need to start a new chat",
  "summarise this for a new session", or "I'm running out of context". Generate a
  structured summary of the current chat so the user can paste it into a new Claude
  session and resume without losing anything.
---

Generate a session summary using the format below.
Only include what has been explicitly discussed in this chat.
Do not guess, infer, or fill in gaps.

## Session summary

**1. What we're working on**
State the main goal or project behind this conversation.

**2. Decisions already made**
List any preferences, constraints, or facts that were established and need to carry forward.

**3. What's next**
State the immediate next task or open question that was about to be tackled.

**4. Dead ends**
List any approaches that were tried and ruled out. (Carrying this forward saves time re-discovering what doesn't work.)

**5. How we're communicating**
Describe the tone and style of this chat.
(e.g. casual and fast / detailed and technical / formal and structured)

---

Rules:
- Bullet points only inside each section
- Only include what was explicitly discussed — no hallucinations, no padding
- No intro, no sign-off, no filler
- Wrap the entire output in a single markdown code block so it is easy to select and copy
