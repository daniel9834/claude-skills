# Voice Profile (Optional)

This file gives you more granular tone control. It's read alongside your config.md when generating proposals. Fill it in if the basic tone description in config isn't enough — skip it if the defaults work fine.

---

## Voice Summary

`[One sentence capturing your brand's overall personality. e.g., "Calm, competent, and direct — like the best operator you've ever worked with."]`

---

## Words and Phrases to USE

List phrases that are distinctly yours — things you actually say to clients:

- `[phrase]` — `[why it fits, e.g., "signals end-to-end service"]`
- `[phrase]` — `[why]`
- `[phrase]` — `[why]`

---

## Words and Phrases to AVOID

Beyond the defaults in SKILL.md, add anything specific to your business:

- `[word/phrase]` — `[reason]`
- `[word/phrase]` — `[reason]`

---

## What On-Brand Looks Like

> `[Write 2-3 example sentences that sound like you. These become the model for proposal copy.]`

---

## What Off-Brand Looks Like

> `[Write 1-2 sentences that sound nothing like you — the generic, corporate version. Helps Claude avoid it.]`

---

## Audience

`[Describe your ideal client in 2-3 sentences: their role, business size, what they care about.]`
